﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - PlayService")]
	public class AN_GetAchievementInfo : FsmStateAction {

		public FsmString achievementId;
		public FsmEvent successEvent;
		public FsmEvent failEvent;


		public FsmString name;
		public FsmString description;
		
		public FsmInt currentSteps;
		public FsmInt totalSteps;
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;

			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if (IsInEdditorMode) {
				Fsm.Event (successEvent);
				Finish ();
				return;
			}

			if (GooglePlayManager.Instance.Achievements.Count == 0) {
				GooglePlayManager.ActionAchievementsLoaded += OnAchievementsLoaded;
				GooglePlayManager.Instance.LoadAchievements ();
			} else {
				OnAchievementsLoadedSuccsess();
			}
		}

		private void OnAchievementsLoaded(GooglePlayResult result) {
			GooglePlayManager.ActionAchievementsLoaded -= OnAchievementsLoaded;

	
			if (result.IsSucceeded) {
				OnAchievementsLoadedSuccsess ();
			} else {
				Fsm.Event(failEvent);
				Finish();
						
			}
		}

		private void OnAchievementsLoadedSuccsess() {
			GPAchievement ach = GooglePlayManager.instance.GetAchievement (achievementId.Value);
			if (ach != null) {
				name.Value = ach.Name;
				description.Value = ach.Description;
				currentSteps.Value = ach.CurrentSteps;
				totalSteps.Value = ach.TotalSteps;

				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
