﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Utils")]
	public class AN_RunApp : FsmStateAction {
				


		public FsmString package;

		public override void OnEnter() {
			AndroidNativeUtility.Instance.StartApplication(package.Value);
			Finish();

		}



	}
}


