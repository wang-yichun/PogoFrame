﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - PlayService")]
	public class AN_ResetAllAchievements : FsmStateAction {

		public override void OnEnter() {
			GooglePlayManager.Instance.ResetAllAchievements();
			Finish();
		}

	}
}
