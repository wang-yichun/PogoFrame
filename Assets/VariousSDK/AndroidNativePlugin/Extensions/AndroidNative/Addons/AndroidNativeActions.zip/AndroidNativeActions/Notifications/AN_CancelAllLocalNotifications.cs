﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - Notifications")]
	public class AN_CancelAllLocalNotifications : FsmStateAction {


				
		public override void OnEnter() {
			AndroidNotificationManager.instance.CancelAllLocalNotifications();
			Finish ();
		}
	}
}
