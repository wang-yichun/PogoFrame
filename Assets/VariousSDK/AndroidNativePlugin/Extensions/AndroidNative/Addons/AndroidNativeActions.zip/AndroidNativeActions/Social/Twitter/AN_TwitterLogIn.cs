using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterLogIn : FsmStateAction {

 
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}

			if(AndroidTwitterManager.instance.IsAuthed) {
				Fsm.Event(successEvent);
				return;
			}

			AndroidTwitterManager.Instance.Init();
			AndroidTwitterManager.Instance.OnAuthCompleteAction += HandleOnAuthCompleteAction;

			AndroidTwitterManager.Instance.AuthenticateUser();
		}

		void HandleOnAuthCompleteAction (TWResult res) {

			if(res.IsSucceeded && AndroidTwitterManager.Instance.IsAuthed) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			AndroidTwitterManager.Instance.OnAuthCompleteAction -= HandleOnAuthCompleteAction;
			Finish();
		}

	}
}


