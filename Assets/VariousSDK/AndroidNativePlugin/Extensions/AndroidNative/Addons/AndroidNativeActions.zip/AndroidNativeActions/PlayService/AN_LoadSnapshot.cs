﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - PlayService")]
	public class AN_LoadSnapshot : FsmStateAction {

		public FsmString SnapshotName;
		
		public FsmEvent Loaded;
		public FsmEvent Failure;

		public FsmString Title;
		public FsmString Description;
		public FsmString CoverImageUri;
		public FsmInt LastModifiedTimestamp;
		public FsmInt TotalPlayedTime;
		public FsmString StringData;

		public override void OnEnter() {
			GooglePlaySavedGamesManager.ActionGameSaveLoaded += HandleActionGameSaveLoaded;
			GooglePlaySavedGamesManager.Instance.LoadSpanshotByName(SnapshotName.Value);
		}

		private void HandleActionGameSaveLoaded (GP_SpanshotLoadResult result)
		{
			GooglePlaySavedGamesManager.ActionGameSaveLoaded += HandleActionGameSaveLoaded;

			if (result.IsSucceeded) {
				Title.Value = result.Snapshot.meta.Title;
				Description.Value = result.Snapshot.meta.Description;
				CoverImageUri.Value = result.Snapshot.meta.CoverImageUrl;
				LastModifiedTimestamp.Value = (int)result.Snapshot.meta.LastModifiedTimestamp;
				TotalPlayedTime.Value = (int)result.Snapshot.meta.TotalPlayedTime;
				StringData.Value = result.Snapshot.stringData;

				Fsm.Event(Loaded);
				Finish();
			} else {
				Fsm.Event(Failure);
				Finish ();
			}
		}

	}
}
