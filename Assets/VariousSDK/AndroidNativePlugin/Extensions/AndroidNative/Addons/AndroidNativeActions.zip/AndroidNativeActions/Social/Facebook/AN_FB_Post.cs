using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Post : FsmStateAction {

		public FsmString link;
		public FsmString linkName;
		public FsmString linkCaption;
		public FsmString linkDescription;
		public FsmString pictureUrl;


		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			SPFacebook.OnPostingCompleteAction += HandleOnPostingCompleteAction;


			SPFacebook.Instance.FeedShare(
				link: link.Value,
				linkName: linkName.Value,
				linkCaption: linkCaption.Value,
				linkDescription: linkDescription.Value,
				picture: pictureUrl.Value
			);


		}

		void HandleOnPostingCompleteAction (FB_PostResult res) {
			if(res.IsSucceeded) {
				Fsm.Event(successEvent);
			} else {
				Fsm.Event(failEvent);
			}

			SPFacebook.OnPostingCompleteAction -= HandleOnPostingCompleteAction;
			Finish();
		}

	}
}


