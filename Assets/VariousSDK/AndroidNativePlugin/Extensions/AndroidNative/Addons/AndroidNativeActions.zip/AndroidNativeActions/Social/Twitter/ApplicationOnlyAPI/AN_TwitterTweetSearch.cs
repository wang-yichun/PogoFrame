﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterTweetSearch : FsmStateAction {
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public FsmString[] loadedTweets;
		public FsmString query;
		public FsmInt count;
		
		public override void OnEnter() {
			TW_SearchTweetsRequest r =  TW_SearchTweetsRequest.Create();
			r.ActionComplete += OnSearchRequestComplete;
			if (query.Value.Length > 0) {
				r.AddParam ("q", query.Value);
			}
			if (count.Value != 0) {
				r.AddParam ("count", count.Value.ToString ());
			}
			r.Send();
		}
		
		private void OnSearchRequestComplete(TW_APIRequstResult result) {
			
			if(result.IsSucceeded) {
				loadedTweets = new FsmString[result.tweets.Count];
				
				for(int i = 0; i < result.tweets.Count; i++) {
					loadedTweets[i].Value = result.tweets[i].text;
				}
				
				Fsm.Event(successEvent);
				Finish();
			} else {
				Fsm.Event(failEvent);
				Finish();
			}
		}
	}
}
