﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_RetriveGCPlayerId : FsmStateAction {
		

		public FsmString playerId;
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		public override void Reset() {
			
		}
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				playerId.Value = "1";
				Finish();
				return;
			}
			



			GameCenterManager.OnAuthFinished += OnAuthFinished;

			if(GameCenterManager.IsInitialized) {
				OnAuth();
			} else {
				GameCenterManager.Init();
			}

			
		}

		private void OnAuthFinished (ISN_Result res) {
			GameCenterManager.OnAuthFinished -= OnAuthFinished;
			if(res.IsSucceeded) {
				OnAuth();
			} else {
				OnAuthFailed();
			}
			
			Finish();
		}
		
		
		private void OnAuth() {

			playerId.Value = GameCenterManager.Player.Id;
			Fsm.Event(successEvent);
		}
		
		private void OnAuthFailed() {
			playerId.Value = "0";
			Fsm.Event(failEvent);
		}
		
		
	}
}