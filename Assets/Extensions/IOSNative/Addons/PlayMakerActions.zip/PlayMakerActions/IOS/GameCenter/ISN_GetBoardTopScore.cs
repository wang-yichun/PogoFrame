﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Game Cneter")]
	public class ISN_GetBoardTopScore : FsmStateAction {
		
		public FsmString leaderboardId;
		public GK_TimeSpan  timeSpan ;
		public GK_CollectionType collection;

		public FsmInt score;
		
		
		public override void OnEnter() {
			
			GK_Leaderboard board = GameCenterManager.GetLeaderboard(leaderboardId.Value);


			if(board != null) {
				GK_Score s = board.GetScore(1, timeSpan, collection);
				if(s != null) {
					Debug.Log("ISN_GetBoardTopScore: Score was already loaded");
					score.Value = (int) s.LongScore;
					Finish();
					return;
				}
				
			} 
			
			SendScoreLoadRequest();
			
			
			
		}
		
		private void SendScoreLoadRequest() {
			Debug.Log("ISN_GetBoardTopScore: Sending score Request");





			GameCenterManager.OnScoresListLoaded -= OnScoresListLoaded;
			GameCenterManager.OnScoresListLoaded += OnScoresListLoaded;
			GameCenterManager.LoadScore(leaderboardId.Value, 1, 5,timeSpan, collection);

		}


		private void OnScoresListLoaded (ISN_Result res) {
			Debug.Log("ISN_GetBoardTopScore: OnScoresListLoaded");
			score.Value = 0;

			if(res.IsSucceeded) {
				GK_Leaderboard board = GameCenterManager.GetLeaderboard(leaderboardId.Value);
				if(board != null) {
					GK_Score s = board.GetScore(1, timeSpan, collection);
					if(s != null) {
						Debug.Log("ISN_GetBoardTopScore: Score Retrived");
						score.Value = (int) s.LongScore;
					}
					
				} 
			}

			Finish();
		}

	}
}



